export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { roomDesc, product, style, wish } = req.body;
  if (!roomDesc || !product) return res.status(400).json({ error: 'Missing parameters' });

  const prompt = `Photorealistic interior design photo. ${roomDesc} The window treatment has been replaced with a ${product} in ${style} color and style.${wish ? ' ' + wish + '.' : ''} All other furniture, walls, floors and lighting remain exactly the same. Professional interior photography, natural daylight, ultra realistic, 4K quality.`;

  try {
    const response = await fetch('https://api.openai.com/v1/images/generations', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'dall-e-3',
        prompt,
        n: 1,
        size: '1024x1024',
        quality: 'standard'
      })
    });

    if (!response.ok) {
      const err = await response.json();
      const msg = err.error?.message || 'Image generation failed';
      return res.status(response.status).json({ error: msg });
    }

    const data = await response.json();
    const url = data.data[0].url;
    return res.status(200).json({ url });

  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}
